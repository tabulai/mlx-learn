"""Clustering on Apple Silicon GPUs."""

from ._e_means import EMeans

__all__ = ["EMeans"]
