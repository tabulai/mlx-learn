// Exact original-coordinate CPU nearest neighbors. No NumPy C API is used.
#define PY_SSIZE_T_CLEAN
#include <Python.h>

#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <limits>
#include <new>
#include <stdexcept>
#include <vector>

#if defined(__aarch64__)
#include <arm_neon.h>
#endif

namespace {

using Key = std::array<std::uint64_t, 10>;

struct Buffer {
    Py_buffer view{};
    bool acquired = false;
    ~Buffer() { if (acquired) PyBuffer_Release(&view); }
};

bool get_buffer(PyObject* object, Buffer& buffer, bool writable, const char* name,
                char format, Py_ssize_t itemsize, std::size_t alignment) {
    int flags = PyBUF_FORMAT | PyBUF_C_CONTIGUOUS;
    if (writable) flags |= PyBUF_WRITABLE;
    if (PyObject_GetBuffer(object, &buffer.view, flags) < 0) return false;
    buffer.acquired = true;
    const auto& v = buffer.view;
    bool correct_format = v.format && v.format[0] == format && v.format[1] == '\0';
    if (format == 'q' && v.format && v.format[0] == 'l' && v.format[1] == '\0')
        correct_format = sizeof(long) == 8;
    if (!correct_format || v.itemsize != itemsize || v.ndim != 2 || !v.shape ||
        v.shape[0] < 0 || v.shape[1] < 0 || v.len < 0 ||
        !PyBuffer_IsContiguous(&v, 'C') ||
        (reinterpret_cast<std::uintptr_t>(v.buf) % alignment) != 0) {
        PyErr_Format(PyExc_ValueError, "%s must be an aligned C-contiguous native %s matrix",
                     name, format == 'f' ? "float32" : format == 'd' ? "float64" : "int64");
        return false;
    }
    if (v.shape[1] > PY_SSIZE_T_MAX / itemsize ||
        (v.shape[1] && v.shape[0] > PY_SSIZE_T_MAX / (v.shape[1] * itemsize)) ||
        v.len != v.shape[0] * v.shape[1] * itemsize || (v.len && !v.buf)) {
        PyErr_Format(PyExc_ValueError, "%s has inconsistent buffer dimensions", name);
        return false;
    }
    auto address = reinterpret_cast<std::uintptr_t>(v.buf);
    if (static_cast<std::uint64_t>(v.len) > std::numeric_limits<std::uintptr_t>::max() - address) {
        PyErr_Format(PyExc_ValueError, "%s has an invalid address span", name);
        return false;
    }
    return true;
}

bool overlaps(const Buffer& a, const Buffer& b) {
    if (!a.acquired || !b.acquired || !a.view.len || !b.view.len) return false;
    auto start_a = reinterpret_cast<std::uintptr_t>(a.view.buf);
    auto start_b = reinterpret_cast<std::uintptr_t>(b.view.buf);
    return start_a < start_b + b.view.len && start_b < start_a + a.view.len;
}

std::uint32_t bits_of(float value) {
    std::uint32_t bits;
    std::memcpy(&bits, &value, sizeof(bits));
    return bits;
}

bool finite_buffer(const float* values, Py_ssize_t count, bool& subnormal, bool& screen) {
    std::uint32_t invalid = 0, tiny = 0, outside = 0;
    for (Py_ssize_t i = 0; i < count; ++i) {
        auto bits = bits_of(values[i]) & 0x7fffffffU;
        invalid |= bits >= 0x7f800000U;
        tiny |= bits && bits < 0x00800000U;
        outside |= bits && (bits < (95U << 23) || bits > (167U << 23));
    }
    subnormal |= tiny != 0;
    screen &= outside == 0;
    return invalid == 0;
}

// Float32 x is exactly signed significand * 2**shift in units of 2**-149.
struct Term { std::uint64_t significand; unsigned shift; bool negative; };
Term decode(float value) {
    auto bits = bits_of(value);
    unsigned exponent = (bits >> 23) & 255U;
    return {static_cast<std::uint64_t>((bits & 0x7fffffU) | (exponent ? 0x800000U : 0)),
            exponent ? exponent - 1 : 0, (bits >> 31) != 0};
}

void add_shifted(Key& accumulator, std::uint64_t value, unsigned shift) {
    if (!value) return;
    unsigned limb = shift / 64;
    unsigned bit = shift % 64;
    unsigned __int128 carry = static_cast<unsigned __int128>(value) << bit;
    while (carry) {
        carry += accumulator[limb];
        accumulator[limb] = static_cast<std::uint64_t>(carry);
        carry >>= 64;
        ++limb;
    }
}

Key exact_squared(const float* query, const float* point, Py_ssize_t features) {
    Key positive{}, negative{}, result{};
    for (Py_ssize_t feature = 0; feature < features; ++feature) {
        Term q = decode(query[feature]), x = decode(point[feature]);
        add_shifted(positive, q.significand * q.significand, 2 * q.shift);
        add_shifted(positive, x.significand * x.significand, 2 * x.shift);
        add_shifted(q.negative == x.negative ? negative : positive,
                    q.significand * x.significand, q.shift + x.shift + 1);
    }
    std::uint64_t borrow = 0;
    for (unsigned limb = 0; limb < result.size(); ++limb) {
        unsigned __int128 subtrahend = static_cast<unsigned __int128>(negative[limb]) + borrow;
        result[limb] = positive[limb] - static_cast<std::uint64_t>(subtrahend);
        borrow = static_cast<unsigned __int128>(positive[limb]) < subtrahend;
    }
    return result;
}

double rounded_squared(const Key& key) {
    int highest_limb = 9;
    while (highest_limb >= 0 && key[highest_limb] == 0) --highest_limb;
    if (highest_limb < 0) return 0;
    unsigned bits = unsigned(highest_limb) * 64 +
                    64 - unsigned(__builtin_clzll(key[highest_limb]));
    if (bits <= 53) return std::ldexp(static_cast<double>(key[0]), -298);

    unsigned shift = bits - 53;
    unsigned limb = shift / 64, bit = shift % 64;
    std::uint64_t significand = key[limb] >> bit;
    if (bit && limb + 1 < key.size()) significand |= key[limb + 1] << (64 - bit);
    unsigned guard_position = shift - 1;
    bool guard = (key[guard_position / 64] >> (guard_position % 64)) & 1;
    bool sticky = false;
    for (unsigned i = 0; i < guard_position / 64; ++i) sticky |= key[i] != 0;
    unsigned tail = guard_position % 64;
    if (tail) sticky |= (key[guard_position / 64] & ((std::uint64_t(1) << tail) - 1)) != 0;
    if (guard && (sticky || (significand & 1))) ++significand;

    // A carry can produce exactly 2**53, still exactly representable. The
    // complete squared-distance range is normal float64, so this power-of-two
    // scaling introduces no further rounding, overflow, or underflow.
    return std::ldexp(static_cast<double>(significand), int(shift) - 298);
}

// The highest single-coordinate squared bit is below 2**556. Even INT32_MAX
// features fit below 2**587; ten limbs leave over 50 spare bits in either sum.
struct Neighbor {
    double squared, lower, upper;
    std::int64_t index;
    bool exact_ready;
    Key exact;
};

void copy_neighbor(Neighbor& destination, const Neighbor& source) {
    destination.squared = source.squared;
    destination.lower = source.lower;
    destination.upper = source.upper;
    destination.index = source.index;
    destination.exact_ready = source.exact_ready;
    if (source.exact_ready) destination.exact = source.exact;
}

int compare(Neighbor& left, Neighbor& right, const float* query,
            const float* train, Py_ssize_t features) {
    if (left.upper < right.lower) return -1;
    if (left.lower > right.upper) return 1;
    // All nonzero original float32 differences have normal float64 squares.
    if (left.squared == 0 && right.squared == 0)
        return left.index < right.index ? -1 : left.index > right.index ? 1 : 0;
    if (!left.exact_ready) {
        left.exact = exact_squared(query, train + left.index * features, features);
        left.exact_ready = true;
    }
    if (!right.exact_ready) {
        right.exact = exact_squared(query, train + right.index * features, features);
        right.exact_ready = true;
    }
    for (int limb = 9; limb >= 0; --limb) {
        if (left.exact[limb] < right.exact[limb]) return -1;
        if (left.exact[limb] > right.exact[limb]) return 1;
    }
    return left.index < right.index ? -1 : left.index > right.index ? 1 : 0;
}

double exact_conversion(float value) {
    auto bits = bits_of(value);
    auto magnitude = bits & 0x7fffffffU;
    if (magnitude && magnitude < 0x00800000U) {
        double result = std::ldexp(static_cast<double>(magnitude), -149);
        return bits >> 31 ? -result : result;
    }
    return static_cast<double>(value);
}

double squared_distance(const float* query, const float* point, Py_ssize_t features,
                        bool subnormal) {
    if (subnormal) {
        double sum = 0;
        for (Py_ssize_t j = 0; j < features; ++j) {
            double delta = exact_conversion(query[j]) - exact_conversion(point[j]);
            sum += delta * delta;
        }
        return sum;
    }
    Py_ssize_t feature = 0;
#if defined(__aarch64__)
    float64x2_t sum_low = vdupq_n_f64(0), sum_high = vdupq_n_f64(0);
    for (; feature + 4 <= features; feature += 4) {
        float32x4_t q = vld1q_f32(query + feature), x = vld1q_f32(point + feature);
        float64x2_t low = vsubq_f64(vcvt_f64_f32(vget_low_f32(q)), vcvt_f64_f32(vget_low_f32(x)));
        float64x2_t high = vsubq_f64(vcvt_f64_f32(vget_high_f32(q)), vcvt_f64_f32(vget_high_f32(x)));
        sum_low = vaddq_f64(sum_low, vmulq_f64(low, low));
        sum_high = vaddq_f64(sum_high, vmulq_f64(high, high));
    }
    double sum = vaddvq_f64(vaddq_f64(sum_low, sum_high));
#else
    double a = 0, b = 0, c = 0, d = 0;
    for (; feature + 4 <= features; feature += 4) {
        double x0 = double(query[feature]) - point[feature];
        double x1 = double(query[feature + 1]) - point[feature + 1];
        double x2 = double(query[feature + 2]) - point[feature + 2];
        double x3 = double(query[feature + 3]) - point[feature + 3];
        a += x0 * x0; b += x1 * x1; c += x2 * x2; d += x3 * x3;
    }
    double sum = (a + b) + (c + d);
#endif
    for (; feature < features; ++feature) {
        double delta = double(query[feature]) - point[feature];
        sum += delta * delta;
    }
    return sum;
}

double screened_squared_distance(const float* query, const float* point,
                                 Py_ssize_t features, double cutoff) {
    // Called only for D<=64 and coordinates zero or in [2**-32, 2**40].
    // Nonzero differences are >=2**-56, their squares >=2**-112, and the
    // complete sum <=2**88. Thus every nonzero arithmetic intermediate is
    // normal float32 and none overflows. The usual relative error bound applies.
    Py_ssize_t feature = 0;
#if defined(__aarch64__)
    float32x4_t a = vdupq_n_f32(0), b = vdupq_n_f32(0);
    float32x4_t c = vdupq_n_f32(0), d = vdupq_n_f32(0);
    if (features >= 16) {
        float32x4_t x0 = vsubq_f32(vld1q_f32(query), vld1q_f32(point));
        float32x4_t x1 = vsubq_f32(vld1q_f32(query + 4), vld1q_f32(point + 4));
        a = vmulq_f32(x0, x0);
        b = vmulq_f32(x1, x1);
        if (double(vaddvq_f32(vaddq_f32(a, b))) > cutoff) return -1;
        feature = 8;
    }
    for (; feature + 16 <= features; feature += 16) {
        float32x4_t x0 = vsubq_f32(vld1q_f32(query + feature), vld1q_f32(point + feature));
        float32x4_t x1 = vsubq_f32(vld1q_f32(query + feature + 4), vld1q_f32(point + feature + 4));
        float32x4_t x2 = vsubq_f32(vld1q_f32(query + feature + 8), vld1q_f32(point + feature + 8));
        float32x4_t x3 = vsubq_f32(vld1q_f32(query + feature + 12), vld1q_f32(point + feature + 12));
        a = vaddq_f32(a, vmulq_f32(x0, x0));
        b = vaddq_f32(b, vmulq_f32(x1, x1));
        c = vaddq_f32(c, vmulq_f32(x2, x2));
        d = vaddq_f32(d, vmulq_f32(x3, x3));
    }
    for (; feature + 4 <= features; feature += 4) {
        float32x4_t delta = vsubq_f32(vld1q_f32(query + feature), vld1q_f32(point + feature));
        a = vaddq_f32(a, vmulq_f32(delta, delta));
    }
    float sum = vaddvq_f32(vaddq_f32(vaddq_f32(a, b), vaddq_f32(c, d)));
#else
    float sum = 0;
    if (features >= 16) {
        for (; feature < 8; ++feature) {
            float delta = query[feature] - point[feature];
            sum += delta * delta;
        }
        if (double(sum) > cutoff) return -1;
    }
#endif
    for (; feature < features; ++feature) {
        float delta = query[feature] - point[feature];
        sum += delta * delta;
    }
    return sum;
}

PyObject* query(PyObject*, PyObject* args) {
    PyObject *train_object, *query_object, *distance_object, *index_object;
    Py_ssize_t k, offset;
    int exclude_self;
    if (!PyArg_ParseTuple(args, "OOnpnOO:query", &train_object, &query_object, &k,
                          &exclude_self, &offset, &distance_object, &index_object)) return nullptr;
    Buffer train, queries, distances, indices;
    if (!get_buffer(train_object, train, false, "train", 'f', 4, alignof(float)) ||
        !get_buffer(query_object, queries, false, "queries", 'f', 4, alignof(float)) ||
        (distance_object != Py_None && !get_buffer(distance_object, distances, true, "distances", 'd', 8, alignof(double))) ||
        !get_buffer(index_object, indices, true, "indices", 'q', 8, alignof(std::int64_t))) return nullptr;
    Py_ssize_t n = train.view.shape[0], features = train.view.shape[1], m = queries.view.shape[0];
    if (n <= 0 || features <= 0 || features > INT32_MAX || queries.view.shape[1] != features ||
        k <= 0 || k > n - exclude_self || offset < 0 ||
        (exclude_self && (offset > n || m > n - offset)) ||
        indices.view.shape[0] != m || indices.view.shape[1] != k ||
        (distances.acquired && (distances.view.shape[0] != m || distances.view.shape[1] != k))) {
        PyErr_SetString(PyExc_ValueError, "invalid nearest-neighbor dimensions, k, or self offset");
        return nullptr;
    }
    if (overlaps(indices, train) || overlaps(indices, queries) || overlaps(distances, train) ||
        overlaps(distances, queries) || overlaps(indices, distances)) {
        PyErr_SetString(PyExc_ValueError, "output buffers must not overlap inputs or each other");
        return nullptr;
    }
    auto* x = static_cast<const float*>(train.view.buf);
    auto* q = static_cast<const float*>(queries.view.buf);
    auto* out_distances = distances.acquired ? static_cast<double*>(distances.view.buf) : nullptr;
    auto* out_indices = static_cast<std::int64_t*>(indices.view.buf);
    bool subnormal = false;
    bool screen = features <= 64;
    if (!finite_buffer(x, n * features, subnormal, screen) ||
        !finite_buffer(q, m * features, subnormal, screen)) {
        PyErr_SetString(PyExc_ValueError, "training and query coordinates must be finite");
        return nullptr;
    }
    try {
        std::vector<Neighbor> best(static_cast<std::size_t>(k));
        const double epsilon = screen ? std::numeric_limits<float>::epsilon()
                                      : std::numeric_limits<double>::epsilon();
        const double error = 16.0 * (double(features) + 1) * epsilon;
        Py_BEGIN_ALLOW_THREADS
        for (Py_ssize_t row = 0; row < m; ++row) {
            const float* current_query = q + row * features;
            Py_ssize_t count = 0;
            double cutoff = std::numeric_limits<double>::infinity();
            for (Py_ssize_t reference = 0; reference < n; ++reference) {
                if (exclude_self && reference == offset + row) continue;
                Neighbor candidate;
                candidate.squared = screen
                    ? screened_squared_distance(current_query, x + reference * features, features, cutoff)
                    : squared_distance(current_query, x + reference * features, features, subnormal);
                if (candidate.squared < 0) continue;
                candidate.lower = candidate.squared * (1 - error);
                candidate.upper = candidate.squared * (1 + error);
                candidate.index = reference;
                candidate.exact_ready = false;
                if (count == k && compare(candidate, best[k - 1], current_query, x, features) >= 0) continue;
                Py_ssize_t position = count < k ? count : k - 1;
                while (position && compare(candidate, best[position - 1], current_query, x, features) < 0) {
                    copy_neighbor(best[position], best[position - 1]);
                    --position;
                }
                copy_neighbor(best[position], candidate);
                if (count < k) ++count;
                if (screen && count == k) {
                    // A partial squared distance has the same conservative
                    // relative error envelope as a full sum. Rounding outward
                    // ensures partial-sum rejection cannot lose a boundary tie.
                    cutoff = std::nextafter(best[k - 1].upper / (1 - error),
                                            std::numeric_limits<double>::infinity());
                }
            }
            for (Py_ssize_t neighbor = 0; neighbor < k; ++neighbor) {
                out_indices[row * k + neighbor] = best[neighbor].index;
                if (out_distances) {
                    // Equal exact keys must also have equal reported distances
                    // and downstream distance weights, independent of feature
                    // order or the approximate reduction's grouping.
                    double squared = best[neighbor].exact_ready ? rounded_squared(best[neighbor].exact)
                        : screen ? squared_distance(current_query, x + best[neighbor].index * features, features, false)
                                 : best[neighbor].squared;
                    out_distances[row * k + neighbor] = std::sqrt(squared);
                }
            }
        }
        Py_END_ALLOW_THREADS
    } catch (const std::bad_alloc&) {
        return PyErr_NoMemory();
    } catch (const std::length_error&) {
        return PyErr_NoMemory();
    }
    Py_RETURN_NONE;
}

PyMethodDef methods[] = {
    {"query", query, METH_VARARGS,
     "query(train, queries, k, exclude_self, offset, distances_or_none, indices) -> None"},
    {nullptr, nullptr, 0, nullptr}
};

PyModuleDef module = {
    PyModuleDef_HEAD_INIT, "_neighbors_cpu_native",
    "Exact original-float32 CPU neighbors with certified dyadic tie ordering.",
    -1, methods, nullptr, nullptr, nullptr, nullptr
};

}  // namespace

PyMODINIT_FUNC PyInit__neighbors_cpu_native() {
    PyObject* result = PyModule_Create(&module);
    if (result && PyModule_AddStringConstant(result, "BUILD_VERSION", "1") < 0) {
        Py_DECREF(result);
        return nullptr;
    }
    return result;
}
