"""Interleave exact archived-native/current CPU kernels, with unchanged threads."""
import hashlib
import importlib.util
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, '/Users/tunguz/Programming/mlxlearn')
import numpy as np
from scipy.spatial.distance import cdist
from threadpoolctl import threadpool_info
from benchmarks.knn_broad_fixtures import _real, workload_specs, _prediction_references
from mlxlearn._kernels import _neighbors_cpu_native as native
from mlxlearn._kernels import neighbors_cpu
from mlxlearn.neighbors import NearestNeighbors, KNeighborsClassifier

previous_path = Path('/tmp/knn-throughput-native-baseline-2026-10-30/_neighbors_cpu_native.cpython-313-darwin.so')
assert hashlib.sha256(previous_path.read_bytes()).hexdigest() == 'bacc58cf95a565df84eb40dd214d97c3bdf646153ff775e5488105f67120c2b7'
spec = importlib.util.spec_from_file_location('_knn_throughput_previous._neighbors_cpu_native', previous_path)
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
output = Path('benchmarks/results/knn-throughput-native-scan-probe-2026-10-30.json')
if output.exists():
    raise FileExistsError(output)

names = ['_native_query', '_native_query_concentrated', '_native_integer_select', '_native_feature_ranges']
original = {name: getattr(neighbors_cpu, name) for name in names}


def configure(mode):
    old = mode == 'archived_native'
    module = previous if old else native
    neighbors_cpu._native_query = module.query
    neighbors_cpu._native_integer_select = module.select_integer_gram
    neighbors_cpu._native_feature_ranges = module.feature_ranges
    neighbors_cpu._native_query_concentrated = {
        'archived_native': None,
        'wide_integer_only': None,
        'first_coordinate_only': lambda *args: native.query_concentrated(*args, True, False),
        'cutoff_only': lambda *args: native.query_concentrated(*args, False, True),
        'combined': native.query_concentrated,
    }[mode]


def audit(result, operation, distances, indices, proba):
    if operation == 'public_proba_distance':
        np.testing.assert_allclose(result, proba, rtol=1e-13, atol=1e-13)
    elif operation == 'selector_only':
        return
    else:
        np.testing.assert_array_equal(result[1], indices)
        np.testing.assert_allclose(result[0], distances, rtol=1e-13, atol=0)


rows = []
try:
    for item in workload_specs():
        if item['source_kind'] != 'bundled_real':
            continue
        arrays, _ = _real(item)
        X, Q = arrays['X'], arrays['Q']
        family = item['dataset']
        if family not in {'digits', 'breast_cancer', 'iris', 'wine'}:
            continue
        modes = (['archived_native', 'wide_integer_only', 'first_coordinate_only', 'cutoff_only', 'combined']
                 if family == 'breast_cancer' else ['archived_native', 'combined'])
        full = cdist(Q.astype(np.float64), X.astype(np.float64), 'sqeuclidean')
        indices = np.argsort(full, axis=1, kind='stable')[:, :5]
        distances = np.sqrt(np.take_along_axis(full, indices, axis=1))
        refs = _prediction_references({**arrays, 'indices': indices, 'distances': distances})
        proba = refs['proba_distance']
        functions = {}
        for mode in modes:
            configure(mode)
            index = neighbors_cpu.CPUIndex(X)
            model = NearestNeighbors(n_neighbors=5, algorithm='brute').fit(X)
            classifier = KNeighborsClassifier(n_neighbors=5, algorithm='brute', weights='distance').fit(X, arrays['y'])
            current = {
                'engine_query': lambda index=index: index.query(Q, 5),
                'engine_first_query': lambda: neighbors_cpu.CPUIndex(X).query(Q, 5),
                'public_query': lambda model=model: model.kneighbors(Q),
                'public_fresh': lambda: NearestNeighbors(n_neighbors=5, algorithm='brute').fit(X).kneighbors(Q),
                'public_proba_distance': lambda classifier=classifier: classifier.predict_proba(Q),
            }
            if family == 'digits':
                dots = Q @ X.T
                xn = np.einsum('ij,ij->i', X, X).reshape(1, -1)
                qn = np.einsum('ij,ij->i', Q, Q).reshape(-1, 1)
                values, ids = np.empty((len(Q), 5), np.float64), np.empty((len(Q), 5), np.int64)
                selector = previous.select_integer_gram if mode == 'archived_native' else native.select_integer_gram
                current['selector_only'] = lambda selector=selector, dots=dots, xn=xn, qn=qn, values=values, ids=ids: selector(dots, xn, qn, 5, False, 0, values, ids)
            functions[mode] = current
            for operation, function in current.items():
                result = function()
                audit(result, operation, distances, indices, proba)
            assert model.last_query_backend_ == 'cpu'
        samples = {mode: {operation: [] for operation in functions[mode]} for mode in modes}
        for repeat in range(12 + 51):
            ordered = modes[repeat % len(modes):] + modes[:repeat % len(modes)]
            for mode in ordered:
                configure(mode)
                for operation, function in functions[mode].items():
                    start = time.perf_counter_ns()
                    result = function()
                    elapsed = (time.perf_counter_ns() - start) / 1000
                    audit(result, operation, distances, indices, proba)
                    if repeat >= 12:
                        samples[mode][operation].append(elapsed)
        case = {'case': item['case']['name'], 'modes': {
            mode: {operation: {'median_us': statistics.median(values), 'samples_us': values}
                   for operation, values in operations.items()}
            for mode, operations in samples.items()}}
        rows.append(case)
        print(case['case'], {mode: {op: round(value['median_us'], 2) for op, value in operations.items()}
                             for mode, operations in case['modes'].items()}, flush=True)
finally:
    for name, value in original.items():
        setattr(neighbors_cpu, name, value)

artifact = {'rows': rows, 'comparison': 'exact archived native binary substituted into current Python wrapper; current modes isolate kernel-only changes',
            'thread_policy': 'unchanged process defaults; no GPU work', 'threadpools': threadpool_info(),
            'rounds': 51, 'warmups': 12, 'ordering': 'rotating modes per round; audits after each timed call',
            'previous_binary_sha256': hashlib.sha256(previous_path.read_bytes()).hexdigest(),
            'current_binary_sha256': hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),
            'current_cpp_sha256': hashlib.sha256(Path('src/mlxlearn/_kernels/_neighbors_cpu_native.cpp').read_bytes()).hexdigest()}
with output.open('x') as stream:
    json.dump(artifact, stream, indent=2)
    stream.write('\n')
