"""MLX-resident Euclidean search and neighbor aggregation, without NumPy.

Small-k GPU searches fuse direct distances and selection. The general path
retains centered Gram tiles, over-selection and direct refinement, with a
distance/index total order at every selection. A small sample of owned training
storage supplies cached dispatch metadata; all search results stay in MLX.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from math import isfinite
from numbers import Integral

import mlx.core as mx

__all__ = ["DeviceNeighborIndex", "fit_neighbors"]


def _use_fused_search(n_features, k):
    # Direct scanning wins for modest feature/neighbor counts; register-heavy
    # larger lists use the GEMM path. See the checked-in before/after panel.
    return n_features <= 32 and k <= 16


def _use_compact_search(n_train, n_query, n_features, k):
    # Amortize compact training storage over a substantial batch. Small shapes
    # keep the direct scan; explicit reference tiling keeps the general path.
    return (16384 <= n_train <= 2**21 and n_query >= 64
            and 16 <= n_features <= 32 and n_features % 4 == 0 and k <= 8)


def _use_integer_search(n_train, n_query, n_features, k):
    # Integer matrix screening amortizes its preparation on larger batches.
    # Older Metal runtimes retain the scalar compact implementation.
    if not (32768 <= n_train <= 2**21 and n_query >= 64
            and n_features == 32 and k <= 8):
        return False
    from ._neighbors_integer import is_supported

    return is_supported()


def _prefer_integer_training(train):
    """Keep concentrated feature variation on the more precise compact filter.

    Integer quantization uses one scale per row. With energy in only a few
    features, its conservative bounds frequently require an expensive complete
    scan even when compact bounds certify the answer. Estimate the effective
    number of varying features from differences between pairs of 16 evenly
    spaced owned rows. Differences avoid sensitivity to a common offset. This
    is a performance heuristic, never a numerical certificate or a change to
    the metric: either route retains exact refinement and its complete fallback.

    Read MLX's buffer interface without a NumPy dependency or an explicit full
    training copy. Exporting a lazy buffer may evaluate it. Python double
    arithmetic avoids FP32 overflow/underflow in the diagnostic. Only this small
    sample is read on the host, once per eligible fitted index; query results
    are never cached. Unsupported buffer exports conservatively retain compact.
    """
    n, features = train.shape
    count = min(16, n)
    energies = [0.0] * features
    try:
        with memoryview(train) as values:
            for pair in range(count // 2):
                first = (2 * pair) * (n - 1) // (count - 1)
                second = (2 * pair + 1) * (n - 1) // (count - 1)
                for feature in range(features):
                    delta = values[first, feature] - values[second, feature]
                    energies[feature] += delta * delta
    except (TypeError, BufferError, NotImplementedError):
        return False
    total = sum(energies)
    # Participation ratio (sum E)^2 / sum(E^2): equal energies give D,
    # whereas a single dominant feature gives 1. Zero columns are harmless.
    return (isfinite(total) and total > 0.0
            and total * total >= 16.0 * sum(energy * energy for energy in energies))


def _matrix(X, *, n_features=None, allow_empty=False):
    if not isinstance(X, mx.array):
        raise TypeError("X must be an MLX array")
    if X.dtype != mx.float32:
        raise TypeError("X must have float32 dtype")
    if X.ndim != 2 or X.shape[1] == 0 or (not allow_empty and X.shape[0] == 0):
        raise ValueError("X must be a nonempty two-dimensional matrix")
    if n_features is not None and X.shape[1] != n_features:
        raise ValueError("X must have the fitted feature count")


def _order_keys(values, indices, excluded=None):
    keys = (values.view(mx.uint32).astype(mx.uint64) << 32) | indices.astype(mx.uint64)
    if excluded is not None:
        # A masked identity must sort after *all* real candidates, including
        # distances that overflow to infinity. Infinity alone is not a mask.
        keys = mx.where(excluded, ~mx.array(0, mx.uint64), keys)
    return keys


@mx.compile
def _ordered_take(values, indices, k, excluded=None):
    """Select using exact float32 distance bits followed by the global index.

    Distances are nonnegative, so their IEEE bit pattern has numeric order.
    A uint64 key avoids adding an epsilon that can change genuinely unequal
    distances. MLX supports this sort on both CPU and Metal.
    """
    keys = _order_keys(values, indices, excluded)
    order = mx.argpartition(keys, kth=k - 1, axis=1)[:, :k]
    return mx.take_along_axis(values, order, axis=1), mx.take_along_axis(indices, order, axis=1)


@mx.compile
def _ordered_sort(values, indices, k, excluded=None):
    keys = _order_keys(values, indices, excluded)
    order = mx.argsort(keys, axis=1)[:, :k]
    return mx.take_along_axis(values, order, axis=1), mx.take_along_axis(indices, order, axis=1)


@dataclass(slots=True)
class DeviceNeighborIndex:
    """Owned float32 training data with reusable device preparation.

    Create with :func:`fit_neighbors`. ``query`` returns ``(distances, indices)``
    as MLX float32/int32 arrays, or ``(None, indices)`` when distances are omitted.
    Explicit ``device='cpu'`` uses MLX CPU operations. The general Gram path has
    the documented float32 candidate-selection limitation; the fused path scans
    every reference using direct differences.
    """

    X: mx.array
    device: str = "gpu"
    _center: object = field(default=None, init=False, repr=False)
    _train: object = field(default=None, init=False, repr=False)
    _train_sq: object = field(default=None, init=False, repr=False)
    _compact: object = field(default=None, init=False, repr=False)
    _integer: object = field(default=None, init=False, repr=False)
    _integer_preferred: bool | None = field(default=None, init=False, repr=False)

    def _prepare_gram(self):
        if self._train is None:
            # Anchoring and quarter scaling avoid overflow in the mean and
            # preserve constant columns, as in logistic input preparation.
            anchor = self.X[0] * 0.25
            self._center = (anchor + mx.mean(self.X * 0.25 - anchor, axis=0)) * 4.0
            self._train = self.X - self._center
            self._train_sq = mx.sum(self._train * self._train, axis=1)
            mx.eval(self._center, self._train, self._train_sq)

    def query(
        self, Q, k, *, return_distance=True, exclude_self=False,
        query_block_size=None, train_block_size=None, _validated=False, _squared=False,
    ):
        """Find neighbors, ordered by distance then training index.

        ``exclude_self`` treats Q as the training rows in their original order.
        It masks each global identity before selection, including duplicate
        rows whose identity would otherwise lie outside the selected prefix.
        Results are evaluated by the caller, or by conversion to a host array.
        """
        _matrix(Q, n_features=self.X.shape[1], allow_empty=True)
        if not isinstance(k, Integral) or isinstance(k, bool) or k < 1:
            raise ValueError("k must be a positive integer")
        k = int(k)
        n_query, n_train = Q.shape[0], self.X.shape[0]
        if exclude_self and n_query != n_train:
            raise ValueError("exclude_self requires the query matrix to be the training matrix")
        limit = n_train - int(exclude_self)
        if k > limit:
            raise ValueError(f"n_neighbors must be <= {limit}, got {k}.")
        for value in (query_block_size, train_block_size):
            if value is not None and (not isinstance(value, Integral) or value < 1):
                raise ValueError("block sizes must be positive integers")
        with mx.stream(mx.gpu if self.device == "gpu" else mx.cpu):
            if not _validated and not bool(mx.all(mx.isfinite(Q))):
                raise ValueError("X must contain only finite values")
            if n_query == 0:
                return (mx.zeros((0, k), mx.float32) if return_distance else None,
                        mx.zeros((0, k), mx.int32))

            # Explicit train tiling is also a useful way to exercise the general
            # path; fused selection owns its own bounded reference partitions.
            fused = self.device == "gpu" and _use_fused_search(self.X.shape[1], k)
            if fused and train_block_size is None:
                from ._neighbors_fused import fused_neighbors

                compact = _use_compact_search(n_train, n_query, self.X.shape[1], k)
                rows = query_block_size or (min(n_query, 1024) if compact else n_query)
                integer = _use_integer_search(
                    n_train, min(n_query, rows), self.X.shape[1], k,
                )
                if integer:
                    if self._integer_preferred is None:
                        self._integer_preferred = _prefer_integer_training(self.X)
                    integer = self._integer_preferred
                out_dist, out_idx = [], []
                for start in range(0, n_query, rows):
                    block = Q[start:start + rows]
                    if integer and block.shape[0] >= 64:
                        from ._neighbors_integer import integer_neighbors, prepare_integer

                        if self._integer is None:
                            self._integer = prepare_integer(self.X)
                        sq, indices = integer_neighbors(
                            self.X, block, k, self._integer,
                            exclude_self=exclude_self, query_offset=start,
                        )
                    elif compact and block.shape[0] >= 64:
                        from ._neighbors_compact import compact_neighbors, prepare_compact

                        if self._compact is None:
                            # These arrays are lazy, owned preparation of X.
                            # Their first evaluation shares the query's graph.
                            self._compact = prepare_compact(self.X)
                        sq, indices = compact_neighbors(
                            self.X, block, k, self._compact,
                            exclude_self=exclude_self, query_offset=start,
                        )
                    else:
                        sq, indices = fused_neighbors(
                            self.X, block, k,
                            exclude_self=exclude_self, query_offset=start,
                        )
                    out_idx.append(indices)
                    if return_distance:
                        out_dist.append(sq if _squared else mx.sqrt(sq))
                    if start + rows < n_query:
                        mx.eval(indices, *([] if not return_distance else [out_dist[-1]]))
                return (mx.concatenate(out_dist) if return_distance else None,
                        mx.concatenate(out_idx))

            self._prepare_gram()
            carry = min(n_train, k + 4)
            rows = min(n_query, query_block_size or 256)
            cols = min(n_train, train_block_size or max(carry, (32 << 20) // (rows * 16)))
            # Bound the direct-refinement gather as well as the distance tile.
            if self.device == "cpu":
                rows = min(rows, max(1, (64 << 20) // (carry * self.X.shape[1] * 8)))
            out_values, out_indices = [], []
            for start in range(0, n_query, rows):
                query = Q[start:start + rows]
                centered = query - self._center
                q_sq = mx.sum(centered * centered, axis=1)[:, None]
                best_values = best_indices = None
                for offset in range(0, n_train, cols):
                    stop = min(offset + cols, n_train)
                    tile = mx.maximum(q_sq + self._train_sq[None, offset:stop]
                                      - 2.0 * (centered @ self._train[offset:stop].T), 0.0)
                    own = mx.arange(start, start + query.shape[0])[:, None] if exclude_self else None
                    take = min(carry, stop - offset)
                    if self.device == "gpu" and take <= 16:
                        from ._neighbors_fused import select_topk

                        # Carry includes four extra slots, so retaining the self
                        # identity here cannot evict a required neighbor. The
                        # subsequent merge/final ordering excludes it explicitly.
                        _, candidates = select_topk(tile, take, offset=offset)
                    else:
                        ids = mx.broadcast_to(mx.arange(offset, stop, dtype=mx.int32), tile.shape)
                        _, candidates = _ordered_take(
                            tile, ids, take, excluded=ids == own if exclude_self else None,
                        )
                    # Refine original coordinates, not separately rounded centered
                    # coordinates. Refine before merging so Gram error from one
                    # tile cannot eliminate another tile's better survivor.
                    if self.device == "gpu":
                        from ._neighbors_fused import refine_neighbors

                        values = refine_neighbors(self.X, query, candidates)
                    else:
                        features = self.X.shape[1]
                        feature_chunk = max(1, (64 << 20) // (candidates.size * 8))
                        values = None
                        for feature in range(0, features, feature_chunk):
                            diff = (self.X[:, feature:feature + feature_chunk][candidates]
                                    - query[:, None, feature:feature + feature_chunk])
                            part = mx.sum(diff * diff, axis=2)
                            values = part if values is None else values + part
                            if feature + feature_chunk < features:
                                mx.eval(values)
                    if best_values is not None:
                        values = mx.concatenate([best_values, values], axis=1)
                        candidates = mx.concatenate([best_indices, candidates], axis=1)
                        best_values, best_indices = _ordered_take(
                            values, candidates, min(carry, values.shape[1]),
                            excluded=candidates == own if exclude_self else None,
                        )
                    else:
                        best_values, best_indices = values, candidates
                    # Bound the live lazy graph to one reference tile. This is
                    # device evaluation, not a transfer of candidates to Python.
                    if stop < n_train:
                        mx.eval(best_values, best_indices)
                best_values, best_indices = _ordered_sort(
                    best_values, best_indices, k,
                    excluded=best_indices == own if exclude_self else None,
                )
                out_indices.append(best_indices)
                if return_distance:
                    out_values.append(best_values if _squared else mx.sqrt(best_values))
            indices = mx.concatenate(out_indices, axis=0)
            distances = mx.concatenate(out_values, axis=0) if return_distance else None
            return distances, indices


def fit_neighbors(X, *, device="gpu", _validated=False):
    """Copy a finite float32 MLX matrix into an owned resident search index.

    NumPy and sklearn are neither imported nor required by this API. Shape and
    finiteness are checked once at fit, and independently for each public query.
    """
    if device not in ("gpu", "cpu"):
        raise ValueError("device must be 'gpu' or 'cpu'")
    _matrix(X)
    if X.shape[0] >= 2**31:
        raise ValueError("training row count must fit int32 indices")
    with mx.stream(mx.gpu if device == "gpu" else mx.cpu):
        # An actual arithmetic copy owns storage even when X wraps borrowed
        # host memory; evaluate before the caller may reuse that input buffer.
        owned = X + mx.zeros((), mx.float32)
        finite = mx.all(mx.isfinite(X)) if not _validated else None
        mx.eval(owned, *([] if finite is None else [finite]))
        if finite is not None and not bool(finite):
            raise ValueError("X must contain only finite values")
        return DeviceNeighborIndex(owned, device=device)


def _weights(distances):
    zero = distances == 0
    has_zero = mx.any(zero, axis=1, keepdims=True)
    # Scaling reciprocal weights by the minimum positive distance preserves
    # their normalized result without overflowing for subnormal distances.
    minimum = mx.min(mx.where(zero, float("inf"), distances), axis=1, keepdims=True)
    relative = minimum / mx.where(zero, 1.0, distances)
    return mx.where(has_zero, zero.astype(mx.float32), relative)


def class_probabilities(indices, targets, n_classes, distances=None, *, squared_distances=False):
    """Device class votes; targets are integer codes, already resident."""
    from ._neighbors_votes import class_probabilities as probabilities

    return probabilities(indices, targets, n_classes, distances,
                         squared_distances=squared_distances)


def regression_predictions(indices, targets, distances=None):
    """Resident float32 regression; sklearn's float64 target path is separate."""
    values = targets[indices]
    if distances is None:
        return mx.mean(values, axis=1)
    weights = _weights(distances)
    return mx.sum(values * weights, axis=1) / mx.sum(weights, axis=1)
