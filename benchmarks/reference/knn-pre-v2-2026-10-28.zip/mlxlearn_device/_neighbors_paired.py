"""Two-query direct scans reuse training loads with independent Kahan sums.

Internal launch helper; shape and dtype validation belongs to fused_neighbors.
Each query retains the same per-pair arithmetic and distance/index ordering as
the one-query scan, including odd query batches and sliced self queries.
"""

from functools import lru_cache

import mlx.core as mx

from mlxlearn_device._neighbors_fused import _HEADER, _merge_kernel

_SCAN = r"""
    #pragma clang fp contract(off)
    #pragma clang fp reassociate(off)
    const uint lane = thread_index_in_simdgroup;
    const uint task = thread_position_in_grid.x / 32;
    const int n_train = shape[0];
    const int n_query = shape[1];
    const int parts = shape[2];
    const int query_base = int(task / uint(parts)) * GROUP;
    if (query_base >= n_query) return;
    const int part = int(task % uint(parts));
    const int begin = int((size_t(part) * size_t(n_train)) / size_t(parts));
    const int end = int((size_t(part + 1) * size_t(n_train)) / size_t(parts));
    const int sentinel = 2147483647;
    float distances[GROUP][K];
    int indices[GROUP][K];
    #pragma clang loop unroll(full)
    for (int q = 0; q < GROUP; ++q) {
        for (int slot = 0; slot < K; ++slot) {
            distances[q][slot] = INFINITY;
            indices[q][slot] = sentinel;
        }
    }
    for (int reference = begin + int(lane); reference < end; reference += 32) {
        float distance[GROUP] = {};
        float correction[GROUP] = {};
        for (int feature = 0; feature < D; ++feature) {
            const float training = train[size_t(reference) * D + feature];
            #pragma clang loop unroll(full)
            for (int q = 0; q < GROUP; ++q) {
                if (TAIL && query_base + q >= n_query) continue;
                const float delta = queries[size_t(query_base + q) * D + feature] - training;
                const float adjusted = delta * delta - correction[q];
                const float total = distance[q] + adjusted;
                correction[q] = (total - distance[q]) - adjusted;
                distance[q] = total;
            }
        }
        #pragma clang loop unroll(full)
        for (int q = 0; q < GROUP; ++q) {
            if (TAIL && query_base + q >= n_query) continue;
            if (EXCLUDE_SELF && reference == query_base + q + shape[3]) continue;
            // Finite inputs have nonnegative squared terms. Once a sum
            // overflows, the guarded reference stays +inf; this unguarded
            // compensation can become NaN, which maps to the same +inf here.
            // Keeping this check outside the feature loop avoids D checks.
            distance[q] = metal::isfinite(distance[q]) ? distance[q] : INFINITY;
            if (neighbor_precedes(distance[q], reference, distances[q][K-1], indices[q][K-1])) {
                int slot = K - 1;
                while (slot > 0 && neighbor_precedes(distance[q], reference,
                                                    distances[q][slot-1], indices[q][slot-1])) {
                    distances[q][slot] = distances[q][slot-1];
                    indices[q][slot] = indices[q][slot-1];
                    --slot;
                }
                distances[q][slot] = distance[q];
                indices[q][slot] = reference;
            }
        }
    }
    #pragma clang loop unroll(full)
    for (int q = 0; q < GROUP; ++q) {
        if (TAIL && query_base + q >= n_query) continue;
        const size_t target = size_t(query_base + q) * parts + part;
        int cursor = 0;
        for (int slot = 0; slot < K; ++slot) {
            const float head = cursor < K ? distances[q][cursor] : INFINITY;
            const int index = cursor < K ? indices[q][cursor] : sentinel;
            const float winner_distance = metal::simd_min(head);
            const int winner_index = metal::simd_min(head == winner_distance ? index : sentinel);
            if (lane == uint(slot) % 32) {
                out_distances[target * K + slot] = winner_distance;
                out_indices[target * K + slot] = winner_index;
            }
            if (index == winner_index && cursor < K) ++cursor;
        }
    }
"""


@lru_cache(maxsize=1)
def _scan_kernel():
    return mx.fast.metal_kernel(
        name="mlxlearn_paired_neighbors_scan",
        input_names=["train", "queries", "shape"],
        output_names=["out_distances", "out_indices"],
        source=_SCAN,
        header=_HEADER,
    )


def paired_neighbors(
    train,
    queries,
    k,
    *,
    partitions,
    exclude_self=False,
    query_offset=0,
):
    group = 2
    n_train, features = train.shape
    n_query = queries.shape[0]
    task_count = ((n_query + group - 1) // group) * partitions
    distances, indices = _scan_kernel()(
        inputs=[train, queries, mx.array([n_train, n_query, partitions, query_offset], mx.int32)],
        template=[
            ("K", int(k)),
            ("D", features),
            ("EXCLUDE_SELF", bool(exclude_self)),
            ("GROUP", int(group)),
            ("TAIL", bool(n_query % group)),
        ],
        grid=(((task_count * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(n_query, partitions, k)] * 2,
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    )
    if partitions == 1:
        return distances.reshape(n_query, k), indices.reshape(n_query, k)
    return tuple(
        _merge_kernel()(
            inputs=[distances, indices, mx.array([partitions, n_query], mx.int32)],
            template=[("K", int(k))],
            grid=(((n_query * 32 + 127) // 128) * 128, 1, 1),
            threadgroup=(128, 1, 1),
            output_shapes=[(n_query, k)] * 2,
            output_dtypes=[mx.float32, mx.int32],
            stream=mx.gpu,
        )
    )
