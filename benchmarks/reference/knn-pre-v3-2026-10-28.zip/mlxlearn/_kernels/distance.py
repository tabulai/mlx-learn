"""Compatibility boundary and memory planning for exact Euclidean neighbors.

The shared search implementation is in ``mlxlearn_device._neighbors``. NumPy is
used here only for host ownership, serialization and sklearn result dtypes; no
search, centering, sorting or self-exclusion runs on the host.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .._common.arrays import INDEX_DTYPE, NUMPY_FLOAT
from .._common.config import get_tuning
from .._common.device import physical_memory_bytes, use_device

__all__ = ["NeighborIndex", "build_index", "resolve_blocks"]

#: Extra candidates carried per tile beyond ``k``. Cheap insurance against a
#: candidate that residual float32 noise in the Gram identity ranked just outside
#: the cut; the refinement pass then orders the enlarged set exactly.
_OVERSELECT = 4


@dataclass(frozen=True, slots=True)
class BlockPlan:
    """How a query is split into tiles."""

    query_rows: int
    train_cols: int

    def __str__(self) -> str:  # pragma: no cover - display only
        return f"query_rows={self.query_rows}, train_cols={self.train_cols}"


def _distance_budget_bytes(backend: str) -> int:
    """Bytes to spend on one distance tile.

    On unified memory a bigger tile means fewer, wider matmuls, which is what the
    GPU wants. The budget is derived from installed memory and clamped, because a
    fixed constant is wrong by an order of magnitude on both an 8 GB Air and a
    128 GB Studio.
    """
    tuning = get_tuning()
    if backend != "mlx":
        return tuning.cpu_distance_block_bytes
    total = physical_memory_bytes()
    if total is None:
        return tuning.distance_block_bytes
    return int(
        min(max(total // 32, tuning.distance_block_bytes), tuning.distance_block_bytes_max)
    )


def resolve_blocks(
    n_query: int,
    n_train: int,
    *,
    backend: str,
    k_search: int,
    query_block_size: int | None = None,
    train_block_size: int | None = None,
) -> BlockPlan:
    """Choose tile sizes so a distance tile fits the budget.

    Unlike the ancestor, the device kind is passed in rather than inferred from
    whether the byte budget happens to exceed a GPU-ish constant — conflating a
    memory budget with a device kind meant an explicit CPU budget above 256 MiB
    silently switched on GPU alignment, and the CPU path could never shrink its
    block no matter how wide the training set was.
    """
    if n_query <= 0 or n_train <= 0:
        return BlockPlan(query_rows=0, train_cols=0)

    tuning = get_tuning()
    budget = _distance_budget_bytes(backend)
    # Distance values, packed ordering keys and selection indices coexist.
    itemsize = 16

    if query_block_size is not None:
        rows = max(1, min(int(query_block_size), n_query))
    else:
        rows = tuning.query_block_rows if backend == "mlx" else tuning.cpu_query_block_rows
        # Keep a full-width tile inside the budget when the training set is small
        # enough to be scanned in one pass; otherwise the train tiling handles it.
        max_rows = budget // max(n_train * itemsize, 1)
        if 0 < max_rows < rows:
            align = tuning.query_block_align if backend == "mlx" else 1
            aligned = (max_rows // align) * align if align > 1 else max_rows
            rows = aligned if aligned > 0 else max_rows
        rows = max(1, min(n_query, rows))

    min_cols = min(k_search, n_train)
    if train_block_size is not None:
        cols = max(min_cols, min(int(train_block_size), n_train))
    else:
        cols = budget // max(rows * itemsize, 1)
        cols = max(min_cols, min(n_train, int(cols)))

    return BlockPlan(query_rows=int(rows), train_cols=int(cols))


@dataclass(slots=True)
class NeighborIndex:
    """Host compatibility state around the shared NumPy-free MLX index.

    Host X remains available for inherited sklearn radius queries and portable
    pickles. Search, centering, selection and refinement run in the device core.
    """

    X: np.ndarray
    backend: str
    _device_index: object = None

    def __post_init__(self):
        self._ensure_device()

    def _ensure_device(self):
        if self._device_index is not None:
            return
        import mlx.core as mx

        from mlxlearn_device import DeviceNeighborIndex

        if self.X.ndim != 2 or 0 in self.X.shape:
            raise ValueError("X must be a nonempty two-dimensional matrix")
        if self.X.shape[0] >= 2**31:
            raise ValueError("training row count must fit int32 indices")
        with use_device("gpu" if self.backend == "mlx" else "cpu"):
            # mx.array copies the already validated, owned NumPy matrix. The
            # public native fit API must additionally own arbitrary MLX inputs,
            # but another arithmetic copy/evaluation here is redundant. Keep
            # mx.array rather than mx.asarray, which can borrow host storage.
            self._device_index = DeviceNeighborIndex(
                mx.array(self.X, dtype=mx.float32),
                device="gpu" if self.backend == "mlx" else "cpu",
            )

    @property
    def device_index(self):
        self._ensure_device()
        return self._device_index

    @property
    def n_samples(self):
        return int(self.X.shape[0])

    @property
    def n_features(self):
        return int(self.X.shape[1])

    def __getstate__(self):
        return {"X": self.X, "backend": self.backend}

    def __setstate__(self, state):
        # Legacy pickles may contain a host center, now derived on the device.
        self.X, self.backend = state["X"], state["backend"]
        self._device_index = None

    def query_device(
        self, Q, k, *, return_distance=True, exclude_self=False,
        query_block_size=None, train_block_size=None, _squared=False,
    ):
        """Return MLX results, without an intermediate host transfer."""
        import mlx.core as mx

        from mlxlearn_device._neighbors import _use_fused_search

        self._ensure_device()
        with use_device("gpu" if self.backend == "mlx" else "cpu"):
            query = Q if isinstance(Q, mx.array) else mx.array(Q, dtype=mx.float32)
            # Keep the existing memory policy, allowing the fused kernel to own
            # its reference partitions unless tiling is explicitly requested.
            plan = resolve_blocks(
                query.shape[0], self.n_samples, backend=self.backend,
                k_search=min(self.n_samples, int(k) + _OVERSELECT),
                query_block_size=query_block_size, train_block_size=train_block_size,
            )
            fused = self.backend == "mlx" and _use_fused_search(self.n_features, k)
            cols = train_block_size if fused else (plan.train_cols or None)
            return self._device_index.query(
                query, k, return_distance=return_distance, exclude_self=exclude_self,
                query_block_size=plan.query_rows or None, train_block_size=cols,
                _validated=True, _squared=_squared,
            )

    def query(
        self, Q, k, *, return_distance=True, exclude_self=False,
        query_block_size=None, train_block_size=None,
    ):
        """Return float64 distances and int64 indices at the sklearn boundary."""
        import mlx.core as mx

        distances, indices = self.query_device(
            Q, k, return_distance=return_distance, exclude_self=exclude_self,
            query_block_size=query_block_size, train_block_size=train_block_size,
            _squared=True,
        )
        mx.eval(indices, *([] if distances is None else [distances]))
        return (None if distances is None else np.sqrt(np.asarray(distances, dtype=np.float64)),
                np.asarray(indices, dtype=INDEX_DTYPE))


def build_index(X: np.ndarray, *, backend: str, _owned: bool = False) -> NeighborIndex:
    """Own host storage for compatibility and prepare the resident MLX index.

    ``_owned`` transfers a freshly allocated, validated conversion buffer from
    the wrapper. It must never be used for a borrowed user input array.
    """
    Xf = (np.asarray(X, dtype=NUMPY_FLOAT, order="C") if _owned
          else np.array(X, dtype=NUMPY_FLOAT, order="C", copy=True))
    return NeighborIndex(X=Xf, backend=backend)
