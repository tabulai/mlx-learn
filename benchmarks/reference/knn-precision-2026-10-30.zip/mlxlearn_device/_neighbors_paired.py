"""Two-query direct scans reuse training loads with independent Kahan sums.

Internal launch helper; shape and dtype validation belongs to fused_neighbors.
Each query retains the same per-pair arithmetic and distance/index ordering as
the one-query scan, including odd query batches and sliced self queries. Feature
counts divisible by four use packed loads without requiring 16-byte alignment;
k=5 uses named candidate scalars rather than a dynamically indexed array.
"""

from functools import lru_cache

import mlx.core as mx

from mlxlearn_device._neighbors_fused import _HEADER, _precise_merge_kernel, _scratch_scan_kernel

from ._neighbors_precision import PRECISION_HEADER

# Four source variants cover k=5 scalar state and general k, each with packed
# or scalar feature loads. This bounds generated source and kernel-factory state.
from ._neighbors_registers import paired_scan_source

_SCAN = paired_scan_source(registers=False, packed=False)


@lru_cache(maxsize=4)
def _scan_kernel(registers=False, packed=False):
    return mx.fast.metal_kernel(
        name=f"mlxlearn_paired_neighbors_scan_{int(registers)}_{int(packed)}",
        input_names=["train", "queries", "shape"],
        output_names=["out_distances", "out_indices"],
        source=paired_scan_source(registers=registers, packed=packed),
        header=_HEADER + PRECISION_HEADER,
    )


def paired_neighbors(
    train,
    queries,
    k,
    *,
    partitions,
    exclude_self=False,
    query_offset=0,
):
    group = 2
    n_train, features = train.shape
    n_query = queries.shape[0]
    if n_query == 0:
        return mx.zeros((0, k), mx.float32), mx.zeros((0, k), mx.int32)
    if k > 8:
        # Exact ambiguity handling with large private arrays overwhelms Metal's
        # compiler. Keep partitioning, using the bounded global-list scan.
        tasks = n_query * partitions
        output = _scratch_scan_kernel()(
            inputs=[train, queries,
                    mx.array([n_train, n_query, features, partitions, query_offset, k], mx.int32)],
            template=[("D", features), ("EXCLUDE_SELF", bool(exclude_self))],
            grid=(((tasks * 32 + 127) // 128) * 128, 1, 1), threadgroup=(128, 1, 1),
            output_shapes=[(n_query, partitions, k)] * 2 + [(tasks, 32, k)] * 2,
            output_dtypes=[mx.float32, mx.int32] * 2, stream=mx.gpu,
        )
        distances, indices = output[:2]
        if partitions == 1:
            return distances.reshape(n_query, k), indices.reshape(n_query, k)
        return tuple(_precise_merge_kernel()(
            inputs=[distances, indices, train, queries, mx.array([partitions, n_query, n_train], mx.int32)],
            template=[("K", k), ("D", features)],
            grid=(((n_query * 32 + 127) // 128) * 128, 1, 1), threadgroup=(128, 1, 1),
            output_shapes=[(n_query, k)] * 2, output_dtypes=[mx.float32, mx.int32], stream=mx.gpu,
        ))
    task_count = ((n_query + group - 1) // group) * partitions
    distances, indices = _scan_kernel(registers=k == 5, packed=features % 4 == 0)(
        inputs=[train, queries, mx.array([n_train, n_query, partitions, query_offset], mx.int32)],
        template=[
            ("K", int(k)),
            ("D", features),
            ("EXCLUDE_SELF", bool(exclude_self)),
            ("TAIL", bool(n_query % group)),
        ],
        grid=(((task_count * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(n_query, partitions, k)] * 2,
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    )
    if partitions == 1:
        return distances.reshape(n_query, k), indices.reshape(n_query, k)
    return tuple(
        _precise_merge_kernel()(
            inputs=[distances, indices, train, queries,
                    mx.array([partitions, n_query, n_train], mx.int32)],
            template=[("K", int(k)), ("D", features)],
            grid=(((n_query * 32 + 127) // 128) * 128, 1, 1),
            threadgroup=(128, 1, 1),
            output_shapes=[(n_query, k)] * 2,
            output_dtypes=[mx.float32, mx.int32],
            stream=mx.gpu,
        )
    )
