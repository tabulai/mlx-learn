"""Adaptive exact ordering of squared distances on original FP32 coordinates.

Ordinary comparisons use conservative intervals around the compensated FP32
distance. Overlapping intervals compare exact dyadic integers, including the
subtraction and product bits discarded by FP32 arithmetic. Returned distances
remain FP32; these helpers only choose their corresponding training indices.
"""

PRECISION_HEADER = r"""
#ifndef MLXLEARN_NEIGHBOR_PRECISION
#define MLXLEARN_NEIGHBOR_PRECISION
#pragma clang fp contract(off)
#pragma clang fp reassociate(off)

// A finite binary32 number is sign*mantissa*2**(shift-149). Subnormals use
// shift=0 without a hidden bit. Decode the bits rather than performing floating
// operations, which are allowed to flush subnormal operands/results to zero.
inline uint precise_mantissa(uint bits) {
    return (bits & 0x007fffffu) | ((bits & 0x7f800000u) ? 0x00800000u : 0u);
}
inline uint precise_shift(uint bits) {
    const uint exponent = (bits >> 23) & 255u;
    return exponent ? exponent - 1u : 0u;
}

// Add/subtract a shifted 48-bit product in a signed two's-complement
// superaccumulator. Nineteen limbs cover every intermediate for positive
// int32 D: four terms per feature have magnitude below 2**557 after scaling
// by 2**298, hence their accumulated magnitude is below 2**588 < 2**607.
inline void precise_add_product(thread uint* accumulator, uint first, uint second,
                                uint shift, bool negative) {
    const ulong product = ulong(first) * ulong(second);
    if (!product) return;
    const uint word = shift >> 5;
    const uint offset = shift & 31u;
    const ulong low = product << offset;
    const uint chunks[3] = {uint(low), uint(low >> 32),
                            offset ? uint(product >> (64u - offset)) : 0u};
    ulong carry = 0;
    for (uint chunk = 0; chunk < 3; ++chunk) {
        const uint position = word + chunk;
        const ulong term = ulong(chunks[chunk]) + carry;
        const uint previous = accumulator[position];
        if (negative) {
            accumulator[position] = previous - uint(term);
            carry = ulong(previous) < term;
        } else {
            const ulong total = ulong(previous) + term;
            accumulator[position] = uint(total);
            carry = total >> 32;
        }
    }
    for (uint position = word + 3; position < 19 && carry; ++position) {
        const uint previous = accumulator[position];
        if (negative) {
            accumulator[position] = previous - 1u;
            carry = previous == 0u;
        } else {
            accumulator[position] = previous + 1u;
            carry = previous == 0xffffffffu;
        }
    }
}

template <int D, typename TrainPointer, typename QueryPointer>
__attribute__((noinline)) int precise_distance_compare(int first, int second,
                                    TrainPointer train, QueryPointer queries, int query) {
    const size_t qa = size_t(query) * D;
    const size_t aa = size_t(first) * D;
    const size_t ba = size_t(second) * D;
    // Common-offset inputs normally share an exponent. Their exact ordering
    // fits a single signed 64-bit accumulator, without the general limb path.
    // Each feature contributes less than 6*2**48 in absolute value.
    if (D <= 4096) {
        const uint exponent = (as_type<uint>(queries[qa]) >> 23) & 255u;
        long difference = 0;
        bool common_exponent = true;
        #pragma clang loop unroll(disable)
        for (int feature = 0; feature < D; ++feature) {
            const uint qb = as_type<uint>(queries[qa + feature]);
            const uint ab = as_type<uint>(train[aa + feature]);
            const uint bb = as_type<uint>(train[ba + feature]);
            if (((qb >> 23) & 255u) != exponent ||
                ((ab >> 23) & 255u) != exponent ||
                ((bb >> 23) & 255u) != exponent) {
                common_exponent = false;
                break;
            }
            const long q = (qb >> 31) ? -long(precise_mantissa(qb)) : long(precise_mantissa(qb));
            const long a = (ab >> 31) ? -long(precise_mantissa(ab)) : long(precise_mantissa(ab));
            const long b = (bb >> 31) ? -long(precise_mantissa(bb)) : long(precise_mantissa(bb));
            difference += a*a - b*b - 2*q*a + 2*q*b;
        }
        if (common_exponent) return difference < 0 ? -1 : int(difference > 0);
    }
    uint accumulator[19];
    for (int word = 0; word < 19; ++word) accumulator[word] = 0u;
    #pragma clang loop unroll(disable)
        for (int feature = 0; feature < D; ++feature) {
        const uint qb = as_type<uint>(queries[qa + feature]);
        const uint ab = as_type<uint>(train[aa + feature]);
        const uint bb = as_type<uint>(train[ba + feature]);
        const uint q = precise_mantissa(qb), a = precise_mantissa(ab), b = precise_mantissa(bb);
        const uint qs = precise_shift(qb), as = precise_shift(ab), bs = precise_shift(bb);
        // ||q-a||**2 - ||q-b||**2 = a*a - b*b - 2*q*a + 2*q*b.
        precise_add_product(accumulator, a, a, 2u*as, false);
        precise_add_product(accumulator, b, b, 2u*bs, true);
        precise_add_product(accumulator, q, a, qs + as + 1u, ((qb ^ ab) >> 31) == 0u);
        precise_add_product(accumulator, q, b, qs + bs + 1u, ((qb ^ bb) >> 31) != 0u);
    }
    if (accumulator[18] & 0x80000000u) return -1;
    uint nonzero = 0u;
    for (int word = 0; word < 19; ++word) nonzero |= accumulator[word];
    return int(nonzero != 0u);
}

// For D<=32, telescoping the Kahan rounding residuals bounds accumulation
// by 4u*S + 512u*u*S; subtraction/products add less than 4u*T. The 32u
// envelope (16 machine epsilons) includes endpoint rounding and inversion.
// Longer sums retain the wider dimension-dependent 20*D*epsilon envelope.
// Restrict the inexpensive filter's dimension/range; all other comparisons
// use exact integers. The absolute floor also covers permitted FP32 flushing.
template <int D>
inline float precise_distance_upper(float value) {
    if (D > 4096 || !(value >= 0.0f && value <= 0x1p110f)) return INFINITY;
    const float relative = (D <= 32 ? 16.0f : 20.0f * float(D)) * 0x1p-23f;
    return value * (1.0f + relative) + float(D) * 0x1p-100f;
}
template <int D>
inline float precise_distance_lower(float value) {
    if (D > 4096 || !(value >= 0.0f && value <= 0x1p110f)) return -INFINITY;
    const float relative = (D <= 32 ? 16.0f : 20.0f * float(D)) * 0x1p-23f;
    return value * (1.0f - relative) - float(D) * 0x1p-100f;
}

template <int D, typename TrainPointer, typename QueryPointer>
inline bool precise_neighbor_precedes(float distance, int index,
                                     float other_distance, int other_index,
                                     TrainPointer train, QueryPointer queries,
                                     int query, int n_train) {
    if (index == other_index || index < 0 || index >= n_train) return false;
    if (other_index < 0 || other_index >= n_train) return true;
    if (precise_distance_upper<D>(distance) < precise_distance_lower<D>(other_distance)) return true;
    if (precise_distance_upper<D>(other_distance) < precise_distance_lower<D>(distance)) return false;
    const int comparison = precise_distance_compare<D>(index, other_index, train, queries, query);
    return comparison < 0 || (comparison == 0 && index < other_index);
}

struct PreciseNeighbor { float distance; int index; };

template <int D, typename TrainPointer, typename QueryPointer>
inline PreciseNeighbor precise_simd_min(float head, int index,
                              TrainPointer train, QueryPointer queries,
                              int query, int n_train) {
    const int sentinel = 2147483647;
    const bool valid = index >= 0 && index < n_train;
    const float provisional_distance = metal::simd_min(valid ? head : INFINITY);
    int winner = metal::simd_min(valid && head == provisional_distance ? index : sentinel);
    if (winner == sentinel) return {INFINITY, winner};
    // Any point capable of beating the provisional winner overlaps its upper
    // endpoint. Ordinary well-separated heads retain the SIMD-min fast path.
    const bool possible = valid &&
        precise_distance_lower<D>(head) <= precise_distance_upper<D>(provisional_distance);
    if (!metal::simd_any(possible && index != winner)) return {provisional_distance, winner};
    float winner_distance = provisional_distance;
    for (;;) {
        const bool better = possible && precise_neighbor_precedes<D>(
            head, index, winner_distance, winner, train, queries, query, n_train);
        const int replacement = metal::simd_min(better ? index : sentinel);
        if (replacement == sentinel) return {winner_distance, winner};
        // Each replacement strictly precedes the previous winner. There are
        // at most 32 real heads, so this exact tournament always terminates.
        winner = replacement;
        winner_distance = metal::simd_min(index == winner ? head : INFINITY);
    }
}
#endif
"""
