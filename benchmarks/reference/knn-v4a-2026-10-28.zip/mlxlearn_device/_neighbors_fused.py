"""Device-only direct Euclidean selection for small neighbor counts.

The streaming local-top-k / SIMD-list-merge design is inspired by the MIT
licensed ``tabulai/mlx-geospatial`` haversine selectors (revision e7af5bac).
This implementation computes Euclidean distances on the original float32
coordinates, partitions long reference scans, and uses SIMD minima to merge
the sorted lists. It does not materialize a query-by-training distance matrix.

Each pair uses a compensated sum of squared differences. Selection
and merging use the total order (squared distance, training index), including
ties at the selection boundary. No host array conversion or synchronization
is performed. Input finiteness is the caller's validation responsibility.
"""

from __future__ import annotations

from functools import lru_cache
from numbers import Integral

import mlx.core as mx

__all__ = ["fused_neighbors", "select_topk", "refine_neighbors"]

_HEADER = """
inline bool neighbor_precedes(float distance, int index,
                              float other_distance, int other_index) {
    return distance < other_distance ||
           (distance == other_distance && index < other_index);
}
"""

_SCAN = """
    #pragma clang fp contract(off)
    #pragma clang fp reassociate(off)
    const uint lane = thread_index_in_simdgroup;
    const uint task = thread_position_in_grid.x / 32;
    const int n_train = shape[0];
    const int n_query = shape[1];
    const int parts = shape[3];
    const int query = int(task / uint(parts));
    if (query >= n_query) return; // uniform across this entire SIMDgroup
    const int part = int(task % uint(parts));
    const int begin = int((size_t(part) * size_t(n_train)) / size_t(parts));
    const int end = int((size_t(part + 1) * size_t(n_train)) / size_t(parts));
    const int sentinel = 2147483647;
    float distances[K];
    int indices[K];
    for (int slot = 0; slot < K; ++slot) {
        distances[slot] = INFINITY;
        indices[slot] = sentinel;
    }
    for (int reference = begin + int(lane); reference < end; reference += 32) {
        if (EXCLUDE_SELF && reference == query + shape[4]) continue;
        float distance = 0.0f;
        float correction = 0.0f;
        for (int feature = 0; feature < D; ++feature) {
            const float delta = queries[size_t(query) * D + feature]
                              - train[size_t(reference) * D + feature];
            const float adjusted = delta * delta - correction;
            const float total = distance + adjusted;
            // Mixed scales must not discard every small squared difference.
            // Keep overflow as +inf instead of contaminating the compensation
            // with inf-inf and losing valid reference indices to NaN.
            correction = metal::isfinite(total) ? (total - distance) - adjusted : 0.0f;
            distance = total;
        }
        if (neighbor_precedes(distance, reference, distances[K - 1], indices[K - 1])) {
            int slot = K - 1;
            while (slot > 0 && neighbor_precedes(distance, reference,
                                                 distances[slot - 1], indices[slot - 1])) {
                distances[slot] = distances[slot - 1];
                indices[slot] = indices[slot - 1];
                --slot;
            }
            distances[slot] = distance;
            indices[slot] = reference;
        }
    }
    // A lane may own all K winners. Advance only the list that supplies the
    // selected head, then reduce again; one winner per lane would be incorrect.
    int cursor = 0;
    for (int slot = 0; slot < K; ++slot) {
        const float head = cursor < K ? distances[cursor] : INFINITY;
        const int index = cursor < K ? indices[cursor] : sentinel;
        const float winner_distance = metal::simd_min(head);
        const int winner_index = metal::simd_min(head == winner_distance ? index : sentinel);
        if (lane == uint(slot) % 32) {
            out_distances[size_t(task) * K + slot] = winner_distance;
            out_indices[size_t(task) * K + slot] = winner_index;
        }
        if (index == winner_index && cursor < K) ++cursor;
    }
"""

_MERGE = """
    const uint lane = thread_index_in_simdgroup;
    const uint query = thread_position_in_grid.x / 32;
    const int parts = shape[0];
    if (query >= uint(shape[1])) return;
    const int sentinel = 2147483647;
    int cursor = 0;
    // Every partition supplies a sorted list; one lane traverses each list.
    for (int slot = 0; slot < K; ++slot) {
        const bool present = lane < uint(parts) && cursor < K;
        const size_t address = (size_t(query) * parts + lane) * K + cursor;
        const float head = present ? partial_distances[address] : INFINITY;
        const int index = present ? partial_indices[address] : sentinel;
        const float winner_distance = metal::simd_min(head);
        const int winner_index = metal::simd_min(head == winner_distance ? index : sentinel);
        if (lane == uint(slot) % 32) {
            out_distances[size_t(query) * K + slot] = winner_distance;
            out_indices[size_t(query) * K + slot] = winner_index;
        }
        if (present && index == winner_index) ++cursor;
    }
"""

_VALUE_SCAN = """
    const uint lane = thread_index_in_simdgroup;
    const uint task = thread_position_in_grid.x / 32;
    const int width = shape[0];
    const int rows = shape[1];
    const int parts = shape[2];
    const int row = int(task / uint(parts));
    if (row >= rows) return;
    const int part = int(task % uint(parts));
    const int begin = int((size_t(part) * size_t(width)) / size_t(parts));
    const int end = int((size_t(part + 1) * size_t(width)) / size_t(parts));
    const int sentinel = 2147483647;
    float distances[K];
    int indices[K];
    for (int slot = 0; slot < K; ++slot) {
        distances[slot] = INFINITY;
        indices[slot] = sentinel;
    }
    for (int col = begin + int(lane); col < end; col += 32) {
        float distance = values[size_t(row) * width + col];
        // Overflow in a Gram tile may produce NaN. Keep a real candidate
        // index so the caller can recompute that candidate's direct distance.
        if (metal::isnan(distance)) distance = INFINITY;
        const int index = col + shape[3];
        if (neighbor_precedes(distance, index, distances[K - 1], indices[K - 1])) {
            int slot = K - 1;
            while (slot > 0 && neighbor_precedes(distance, index,
                                                 distances[slot - 1], indices[slot - 1])) {
                distances[slot] = distances[slot - 1];
                indices[slot] = indices[slot - 1];
                --slot;
            }
            distances[slot] = distance;
            indices[slot] = index;
        }
    }
    int cursor = 0;
    for (int slot = 0; slot < K; ++slot) {
        const float head = cursor < K ? distances[cursor] : INFINITY;
        const int index = cursor < K ? indices[cursor] : sentinel;
        const float winner_distance = metal::simd_min(head);
        const int winner_index = metal::simd_min(head == winner_distance ? index : sentinel);
        if (lane == uint(slot) % 32) {
            out_distances[size_t(task) * K + slot] = winner_distance;
            out_indices[size_t(task) * K + slot] = winner_index;
        }
        if (index == winner_index && cursor < K) ++cursor;
    }
"""

_REFINE = """
    #pragma clang fp contract(off)
    #pragma clang fp reassociate(off)
    const size_t item = thread_position_in_grid.x;
    const int n_train = shape[0];
    const int n_query = shape[1];
    const int width = shape[2];
    if (item >= size_t(n_query) * width) return;
    const int query = int(item / width);
    const int reference = indices[item];
    if (reference < 0 || reference >= n_train) {
        out_distances[item] = INFINITY;
        return;
    }
    float distance = 0.0f;
    float correction = 0.0f;
    for (int feature = 0; feature < D; ++feature) {
        const float delta = queries[size_t(query) * D + feature]
                          - train[size_t(reference) * D + feature];
        const float adjusted = delta * delta - correction;
        const float total = distance + adjusted;
        correction = metal::isfinite(total) ? (total - distance) - adjusted : 0.0f;
        distance = total;
    }
    out_distances[item] = distance;
"""


@lru_cache(maxsize=1)
def _scan_kernel():
    return mx.fast.metal_kernel(
        name="mlxlearn_direct_neighbors_scan",
        input_names=["train", "queries", "shape"],
        output_names=["out_distances", "out_indices"],
        source=_SCAN,
        header=_HEADER,
    )


@lru_cache(maxsize=1)
def _merge_kernel():
    return mx.fast.metal_kernel(
        name="mlxlearn_direct_neighbors_merge",
        input_names=["partial_distances", "partial_indices", "shape"],
        output_names=["out_distances", "out_indices"],
        source=_MERGE,
    )


@lru_cache(maxsize=1)
def _value_kernel():
    return mx.fast.metal_kernel(
        name="mlxlearn_neighbor_value_select",
        input_names=["values", "shape"],
        output_names=["out_distances", "out_indices"],
        source=_VALUE_SCAN,
        header=_HEADER,
    )


@lru_cache(maxsize=1)
def _refine_kernel():
    return mx.fast.metal_kernel(
        name="mlxlearn_neighbor_direct_refine",
        input_names=["train", "queries", "indices", "shape"],
        output_names=["out_distances"],
        source=_REFINE,
    )


def _partitions(n_query: int, n_train: int) -> int:
    """Partition value-only selection without large merge buffers."""
    return min(32, max(1, n_train // 512), max(1, (256 + n_query - 1) // n_query))


def _scan_partitions(n_query: int, n_train: int) -> int:
    """Expose enough independent distance scans to occupy the GPU.

    Direct distances do substantially more work than value-only selection.
    Targeting just 256 SIMDgroups left ordinary batches with long serial scans.
    Up to 4096 groups shortens those scans while retaining at least 512 training
    rows per partition and bounding the GPU merge to 32 sorted lists.
    """
    return min(32, max(1, n_train // 512), max(1, (4096 + n_query - 1) // n_query))


def fused_neighbors(
    train: mx.array,
    queries: mx.array,
    k: int,
    *,
    exclude_self: bool = False,
    query_offset: int = 0,
) -> tuple[mx.array, mx.array]:
    """Return sorted squared float32 distances and int32 training indices.

    Both arguments must be float32 MLX matrices with the same positive feature
    count, and the active device must be Metal. ``1 <= k <= 32``. With
    ``exclude_self``, query row ``i`` excludes training row ``query_offset+i``;
    the caller guarantees the queries are the corresponding training slice.
    The outputs remain lazy MLX arrays, ready for further device computation.
    """
    for name, array in (("train", train), ("queries", queries)):
        if not isinstance(array, mx.array):
            raise TypeError(f"{name} must be an MLX array")
        if array.ndim != 2:
            raise ValueError(f"{name} must be a two-dimensional matrix")
        if array.dtype != mx.float32:
            raise TypeError(f"{name} must have float32 dtype")
    if train.shape[1] == 0 or train.shape[1] != queries.shape[1]:
        raise ValueError("train and queries must have the same positive feature count")
    if isinstance(k, bool) or not isinstance(k, Integral):
        raise TypeError("k must be an integer")
    if not 1 <= k <= min(32, train.shape[0] - int(exclude_self)):
        raise ValueError("k must be between 1 and 32 and no larger than the available references")
    if isinstance(query_offset, bool) or not isinstance(query_offset, Integral):
        raise TypeError("query_offset must be an integer")
    if query_offset < 0 or (exclude_self and query_offset + queries.shape[0] > train.shape[0]):
        raise ValueError("query_offset must locate the query slice within the training matrix")
    if max(train.shape + queries.shape + (query_offset,)) >= 2**31:
        raise ValueError("fused neighbor dimensions must fit int32 indexing")
    if not mx.metal.is_available() or mx.default_device() != mx.gpu:
        raise RuntimeError("fused_neighbors requires the active MLX GPU device")
    n_query, features = queries.shape
    if n_query == 0:
        return mx.zeros((0, k), mx.float32), mx.zeros((0, k), mx.int32)
    parts = _scan_partitions(n_query, train.shape[0])
    # Tiny query batches benefit more from independent SIMDgroups than reuse.
    if train.shape[0] >= 8192 and n_query >= 32 and features <= 32 and k <= 16:
        from ._neighbors_paired import paired_neighbors

        return paired_neighbors(
            train, queries, k, partitions=parts,
            exclude_self=exclude_self, query_offset=query_offset,
        )
    task_count = n_query * parts
    shape = mx.array([train.shape[0], n_query, features, parts, query_offset], mx.int32)
    distances, indices = _scan_kernel()(
        inputs=[train, queries, shape],
        template=[("K", int(k)), ("D", features), ("EXCLUDE_SELF", bool(exclude_self))],
        grid=(((task_count * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(n_query, parts, k), (n_query, parts, k)],
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    )
    if parts == 1:
        return distances.reshape(n_query, k), indices.reshape(n_query, k)
    return tuple(_merge_kernel()(
        inputs=[distances, indices, mx.array([parts, n_query], mx.int32)],
        template=[("K", int(k))],
        grid=(((n_query * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(n_query, k), (n_query, k)],
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    ))


def select_topk(values: mx.array, k: int, *, offset: int = 0) -> tuple[mx.array, mx.array]:
    """Select sorted row minima without a full-shaped sort-index allocation.

    ``values`` is a float32 matrix; ``1 <= k <= 128``. Returned global column
    indices include ``offset`` and break equal-value ties. NaN entries are
    treated as positive infinity. Both result arrays remain on the GPU.
    """
    if not isinstance(values, mx.array) or values.dtype != mx.float32:
        raise TypeError("values must be a float32 MLX array")
    if values.ndim != 2:
        raise ValueError("values must be a two-dimensional matrix")
    if isinstance(k, bool) or not isinstance(k, Integral):
        raise TypeError("k must be an integer")
    if not 1 <= k <= min(128, values.shape[1]):
        raise ValueError("k must be between 1 and min(128, values.shape[1])")
    if isinstance(offset, bool) or not isinstance(offset, Integral):
        raise TypeError("offset must be an integer")
    if offset < 0 or values.shape[1] + offset >= 2**31 or values.shape[0] >= 2**31:
        raise ValueError("global column indices and row count must fit int32")
    if not mx.metal.is_available() or mx.default_device() != mx.gpu:
        raise RuntimeError("select_topk requires the active MLX GPU device")
    rows, width = values.shape
    if rows == 0:
        return mx.zeros((0, k), mx.float32), mx.zeros((0, k), mx.int32)
    parts = _partitions(rows, width)
    task_count = rows * parts
    partial_values, partial_indices = _value_kernel()(
        inputs=[values, mx.array([width, rows, parts, offset], mx.int32)],
        template=[("K", int(k))],
        grid=(((task_count * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(rows, parts, k), (rows, parts, k)],
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    )
    if parts == 1:
        return partial_values.reshape(rows, k), partial_indices.reshape(rows, k)
    return tuple(_merge_kernel()(
        inputs=[partial_values, partial_indices, mx.array([parts, rows], mx.int32)],
        template=[("K", int(k))],
        grid=(((rows * 32 + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[(rows, k), (rows, k)],
        output_dtypes=[mx.float32, mx.int32],
        stream=mx.gpu,
    ))


def refine_neighbors(train: mx.array, queries: mx.array, indices: mx.array) -> mx.array:
    """Recompute candidate distances with the fused scan's compensated order.

    One thread accumulates each candidate pair directly from original inputs,
    so temporary storage is proportional to the output rather than B*k*D.
    Invalid candidate indices produce positive infinity without an invalid
    read. All valid pair distances match ``fused_neighbors`` bit for bit.
    """
    for name, array in (("train", train), ("queries", queries)):
        if not isinstance(array, mx.array) or array.dtype != mx.float32:
            raise TypeError(f"{name} must be a float32 MLX array")
        if array.ndim != 2:
            raise ValueError(f"{name} must be a two-dimensional matrix")
    if train.shape[1] == 0 or train.shape[1] != queries.shape[1]:
        raise ValueError("train and queries must have the same positive feature count")
    if not isinstance(indices, mx.array) or indices.dtype != mx.int32:
        raise TypeError("indices must be an int32 MLX array")
    if indices.ndim != 2 or indices.shape[0] != queries.shape[0]:
        raise ValueError("indices must be a matrix with one row per query")
    if not mx.metal.is_available() or mx.default_device() != mx.gpu:
        raise RuntimeError("refine_neighbors requires the active MLX GPU device")
    if indices.size == 0:
        return mx.zeros(indices.shape, mx.float32)
    (distances,) = _refine_kernel()(
        inputs=[train, queries, indices,
                mx.array([train.shape[0], queries.shape[0], indices.shape[1]], mx.int32)],
        template=[("D", train.shape[1])],
        grid=(((indices.size + 127) // 128) * 128, 1, 1),
        threadgroup=(128, 1, 1),
        output_shapes=[indices.shape],
        output_dtypes=[mx.float32],
        stream=mx.gpu,
    )
    return distances
